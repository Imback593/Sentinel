import socket
import threading

clients = []

def handle_client(conn, addr):
    print(f"Подключился клиент: {addr}")
    clients.append(conn)

    while True:
        try:
            data = conn.recv(1024)
            if not data:
                break
        except:
            break

        # Рассылаем сообщение всем клиентам, кроме отправителя
        for client in clients:
            if client != conn:
                try:
                    client.send(data)
                except:
                    pass

    conn.close()
    clients.remove(conn)
    print(f"Клиент отключился: {addr}")

def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("127.0.0.1", 5001))
    server.listen()

    print("Сервер запущен на порту 5000")

    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle_client, args=(conn, addr)).start()

start_server()