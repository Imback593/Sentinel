import socket 
import threading

SOCKET = socket.socket()

class client():
    
    def connect(ip, port):
        CONNECTIP = ip
        PORT = port   
        SOCKET.connect((f"{CONNECTIP}", int(PORT)))
        print(f"[CLIENT] Connecting to {CONNECTIP}")
    
    def listening():
        DATA = SOCKET.recv(2048)
        if DATA == None:
            DATA = SOCKET.recv(2048)
        else: 
            return DATA.decode()

    def sending(message):
        SOCKET.send(message.encode())
        






       

