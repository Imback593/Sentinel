import sys
import threading
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget,
    QVBoxLayout, QHBoxLayout, QTextEdit,
    QLineEdit, QPushButton, QListWidget,
    QLabel, QFormLayout, QStackedWidget,
    QMessageBox, QCheckBox, QSlider, QTabWidget,
    QGroupBox
)
from PySide6.QtCore import (
    Slot, Signal, Qt, QPropertyAnimation, QRect, 
    QPoint, QEasingCurve, QUrl
)
from PySide6.QtGui import QPainter

import test_QSS
from test_QSS import testt_QSS
from test_logframe import login_frame


class main_window(QMainWindow):
    def __init__(self):
        super().__init__()

        self.main_frame = login_frame

        self.stack = QStackedWidget()
        self.stack.addWidget(self.main_frame)
        self.setCentralWidget(self.stack)
        
        self.show_window()
    
    @Slot()
    def show_window(self):
        self.setWindowTitle("Login")
        self.setFixedSize(400,800)
        self.stack.setCurrentWidget(self.main_frame)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # *** ЗАСТОСОВУЄМО СТИЛЬ ***
    app.setStyleSheet(testt_QSS.QSS)
    
    window = main_window()
    window.show()
    
    sys.exit(app.exec())