import sys
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget,
    QVBoxLayout, QHBoxLayout, QTextEdit,
    QLineEdit, QPushButton, QListWidget,
    QLabel, QFormLayout, QStackedWidget,
    QMessageBox, QCheckBox, QSlider, QTabWidget,
    QGroupBox,
)
from PySide6.QtCore import (
    Slot, Signal, Qt, QPropertyAnimation, QRect, 
    QPoint, QEasingCurve, QUrl
)

class login_frame(QWidget):
   def __init__(self):
      super().__init__()
      self.setWindowTitle("Sentinel")
      self.setGeometry(100,100,400,800)
      
      self.main_layout = QVBoxLayout()
      self.sub_widget = QWidget()
      self.top_label_layout = QVBoxLayout()
      self.sub_widget.setLayout(self.top_label_layout)
      self.form_widget = QWidget()
      self.form_layout = QVBoxLayout()
      self.form_widget.setLayout(self.form_layout)
    
      self.login_label = QLabel()
      self.form_login_label = QLabel()
      self.form_login_input = QTextEdit()
      self.form_password_label = QLabel()
      self.form_password_input = QTextEdit()
      self.form_login_button = QPushButton()
      self.form_signup_switch = QLabel()

      self.main_layout.addWidget(self.sub_widget)
      self.main_layout.addWidget(self.form_widget)

      self.top_label_layout.addWidget(self.login_label)
      self.form_layout.addWidget(self.form_login_label)
      self.form_layout.addWidget(self.form_login_input)
      self.form_layout.addWidget(self.form_password_label)
      self.form_layout.addWidget(self.form_password_input)
      self.form_layout.addWidget(self.form_signup_switch)
      
      
