
class testt_QSS():
    QSS = """
    QLabel {
        background-color: #E0E0E0;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    """